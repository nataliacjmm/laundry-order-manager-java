package controlador;

import modelo.Pedido;
import modelo.EstadoPedido;
import com.google.gson.Gson;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ControladorPedidos {
    private static final String ARCHIVO_PEDIDOS = "pedidos.json";
    private static List<Pedido> pedidos = new ArrayList<>();

    public ControladorPedidos() {
        cargarPedidos();
    }

    public List<Pedido> getPedidos() {
        return pedidos;
    }

    public void agregarPedido(Pedido pedido) {
        pedidos.add(pedido);
        guardarPedidos();
    }

    // Actualizamos el estado recibiendo un EstadoPedido en lugar de un String
    public void actualizarEstadoPedido(int id, EstadoPedido nuevoEstado) {
        for (Pedido p : pedidos) {
            if (p.getId() == id) {
                p.setEstado(nuevoEstado);
                guardarPedidos();
                break;
            }
        }
    }

    public void guardarPedidos() {
        try (FileWriter writer = new FileWriter(ARCHIVO_PEDIDOS)) {
            new Gson().toJson(pedidos, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cargarPedidos() {
        try (FileReader reader = new FileReader(ARCHIVO_PEDIDOS)) {
            Pedido[] array = new Gson().fromJson(reader, Pedido[].class);
            if (array != null) {
                pedidos = new ArrayList<>(Arrays.asList(array));
            } else {
                pedidos = new ArrayList<>();
            }
        } catch (IOException e) {
            pedidos = new ArrayList<>();
        }
    }
}
