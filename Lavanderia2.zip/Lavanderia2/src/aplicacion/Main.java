package aplicacion;

import controlador.ControladorPedidos;
import controlador.ControladorLavadora;
import vista.*;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Inicializar controladores
        ControladorPedidos controladorPedidos = new ControladorPedidos();
        ControladorLavadora controladorLavadora = new ControladorLavadora();

        // Crear la ventana principal
        JFrame frame = new JFrame("Lavandería");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1100, 1000);
        frame.setLocationRelativeTo(null);

        // Crear el JTabbedPane
        JTabbedPane pestañas = new JTabbedPane();

        // Agregar pestañas para Cliente y Administrador
        pestañas.addTab("Cliente", new VistaMenuCliente(controladorPedidos, controladorLavadora, pestañas));
        pestañas.addTab("Administrador", new VistaAdminPedidos(controladorPedidos, controladorLavadora, pestañas));

        // Agregar el JTabbedPane a la ventana
        frame.add(pestañas);
        frame.setVisible(true);
    }
}
