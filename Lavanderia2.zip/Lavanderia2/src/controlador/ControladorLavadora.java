package controlador;

import modelo.Lavadora;
import modelo.Pedido;
import java.util.ArrayList;
import java.util.List;

public class ControladorLavadora {
    private List<Lavadora> lavadoras;

    public ControladorLavadora() {
        this.lavadoras = new ArrayList<>();
        inicializarLavadoras();
    }

    // Inicializa algunas lavadoras disponibles
    private void inicializarLavadoras() {
        lavadoras.add(new Lavadora(1, "LG TurboWash"));
        lavadoras.add(new Lavadora(2, "Samsung EcoBubble"));
    }

    // Devuelve la lista de lavadoras
    public List<Lavadora> getLavadoras() {
        return lavadoras;
    }

    // Inicia un lavado asignando un pedido a la lavadora identificada por id
    public boolean iniciarLavado(int idLavadora, Pedido pedido) {
        for (Lavadora lavadora : lavadoras) {
            if (lavadora.getId() == idLavadora && !lavadora.isEnUso()) {
                lavadora.iniciarLavado(pedido);
                return true;
            }
        }
        return false;
    }
    
    // Finaliza el lavado de una lavadora, marcándola como disponible
    public void finalizarLavado(int idLavadora) {
        for (Lavadora lavadora : lavadoras) {
            if (lavadora.getId() == idLavadora && lavadora.isEnUso()) {
                lavadora.finalizarLavado();
                return;
            }
        }
    }
}
