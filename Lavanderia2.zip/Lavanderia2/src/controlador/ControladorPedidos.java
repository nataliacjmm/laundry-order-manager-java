package controlador;


import modelo.Pedido;
import modelo.EstadoPedido;
import com.google.gson.Gson;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import dao.PedidoDAO;
import dao.PedidoDAOInterface;

public class ControladorPedidos {
    
    private PedidoDAOInterface pedidoDAO;
    /*private static final String ARCHIVO_PEDIDOS = "pedidos.json";
    private static List<Pedido> pedidos = new ArrayList<>();*/

    public ControladorPedidos() {
        //cargarPedidos();
        this.pedidoDAO = new PedidoDAO();
    }

    public List<Pedido> getPedidos() {
        //return pedidos;
        return pedidoDAO.obtenerTodosLosPedidos();

    }

    public void agregarPedido(Pedido pedido) {
        //pedidos.add(pedido);
        //guardarPedidos();
        pedidoDAO.agregarPedido(pedido);

    }

    // Actualizamos el estado recibiendo un EstadoPedido en lugar de un String
    public void actualizarEstadoPedido(int id, EstadoPedido nuevoEstado) {
        
        Pedido pedido = pedidoDAO.obtenerPedidoPorId(id);
        if (pedido != null) {
            pedido.setEstado(nuevoEstado);
            pedidoDAO.actualizarPedido(pedido);
        }
        /*
        for (Pedido p : pedidos) {
            if (p.getId() == id) {
                p.setEstado(nuevoEstado);
                guardarPedidos();
                break;
            }
        }*/
    }
/*
    public void guardarPedidos() {
        try (FileWriter writer = new FileWriter(ARCHIVO_PEDIDOS)) {
            new Gson().toJson(pedidos, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cargarPedidos() {
        try (FileReader reader = new FileReader(ARCHIVO_PEDIDOS)) {
            Pedido[] array = new Gson().fromJson(reader, Pedido[].class);
            if (array != null) {
                pedidos = new ArrayList<>(Arrays.asList(array));
            } else {
                pedidos = new ArrayList<>();
            }
        } catch (IOException e) {
            pedidos = new ArrayList<>();
        }
    }*/
}
