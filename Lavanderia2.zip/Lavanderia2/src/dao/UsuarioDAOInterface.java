package dao;

import modelo.Usuario;
import java.util.List;

public interface UsuarioDAOInterface {
    void agregarUsuario(Usuario usuario);
    Usuario getUsuarioPorId(int id);
    List<Usuario> getUsuarios();
    void actualizarUsuario(Usuario usuario);
    void eliminarUsuario(int id);
}
