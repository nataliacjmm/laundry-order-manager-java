package dao;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import modelo.Pedido;
import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO implements PedidoDAOInterface {
    private static final String ARCHIVO_PEDIDOS = "pedidos.json";
    private List<Pedido> pedidos;

    public PedidoDAO() {
        this.pedidos = cargarPedidos();
    }

    @Override
    public void agregarPedido(Pedido pedido) {
        pedidos.add(pedido);
        guardarPedidos();
    }

    @Override
    public Pedido obtenerPedidoPorId(int id) {
        for (Pedido p : pedidos) {
            if (p.getId() == id) {
                return p;
            }
        }
        return null; // Si no se encuentra el pedido
    }

    @Override
    public List<Pedido> obtenerTodosLosPedidos() {
        return new ArrayList<>(pedidos);
    }

    @Override
    public void actualizarPedido(Pedido pedido) {
        for (int i = 0; i < pedidos.size(); i++) {
            if (pedidos.get(i).getId() == pedido.getId()) {
                pedidos.set(i, pedido);
                guardarPedidos();
                return;
            }
        }
    }

    @Override
    public void eliminarPedido(int id) {
        pedidos.removeIf(p -> p.getId() == id);
        guardarPedidos();
    }

    
    private void guardarPedidos() {
        try (FileWriter writer = new FileWriter(ARCHIVO_PEDIDOS)) {
            new Gson().toJson(pedidos, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private List<Pedido> cargarPedidos() {
        try (FileReader reader = new FileReader(ARCHIVO_PEDIDOS)) {
            Type listType = new TypeToken<List<Pedido>>() {}.getType();
            List<Pedido> lista = new Gson().fromJson(reader, listType);
            return lista != null ? lista : new ArrayList<>();
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }
}
