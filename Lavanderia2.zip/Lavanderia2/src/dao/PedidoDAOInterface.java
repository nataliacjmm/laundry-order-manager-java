package dao;

import modelo.Pedido;
import java.util.List;

public interface PedidoDAOInterface {
    void agregarPedido(Pedido pedido);
    Pedido obtenerPedidoPorId(int id);
    List<Pedido> obtenerTodosLosPedidos();
    void actualizarPedido(Pedido pedido);
    void eliminarPedido(int id);
}
