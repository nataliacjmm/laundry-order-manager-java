package dao;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import modelo.Usuario;
import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO implements UsuarioDAOInterface {
    private static final String ARCHIVO_USUARIOS = "usuarios.json";
    private List<Usuario> usuarios;

    public UsuarioDAO() {
        this.usuarios = cargarUsuarios();
    }
    

    @Override
    public void agregarUsuario(Usuario usuario) {
        usuarios.add(usuario);
        guardarUsuarios();
    }

    @Override
    public Usuario getUsuarioPorId(int id) {
        for (Usuario u : usuarios) {
            if (u.getId() == id) {  
                return u;
            }
        }
        return null;
    }

    @Override
    public List<Usuario> getUsuarios() {
        return new ArrayList<>(usuarios);
    }

    @Override
    public void actualizarUsuario(Usuario usuario) {
        for (int i = 0; i < usuarios.size(); i++) {
            if (usuarios.get(i).getId() == usuario.getId()) {  
                usuarios.get(i).setNombre(usuario.getNombre());  
                usuarios.get(i).setEmail(usuario.getEmail());   
                usuarios.get(i).setTelefono(usuario.getTelefono());  
                guardarUsuarios();
                return;
            }
        }
    }

    @Override
    public void eliminarUsuario(int id) {
        usuarios.removeIf(u -> u.getId() == id);  
        guardarUsuarios();
    }

    private void guardarUsuarios() {
        try (FileWriter writer = new FileWriter(ARCHIVO_USUARIOS)) {
            new Gson().toJson(usuarios, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private List<Usuario> cargarUsuarios() {
        try (FileReader reader = new FileReader(ARCHIVO_USUARIOS)) {
            Type listType = new TypeToken<List<Usuario>>() {}.getType();
            List<Usuario> lista = new Gson().fromJson(reader, listType);
            return lista != null ? lista : new ArrayList<>();
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }
}
