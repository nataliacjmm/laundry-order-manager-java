package modelo;

public class Configuracion {
    private String modo;
    private int temperatura;
    private int duracion; // Duración en minutos

    public Configuracion(String modo, int temperatura, int duracion) {
        this.modo = modo;
        this.temperatura = temperatura;
        this.duracion = duracion;
    }

    public String getModo() {
        return modo;
    }

    public void setModo(String modo) {
        this.modo = modo;
    }

    public int getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(int temperatura) {
        this.temperatura = temperatura;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    @Override
    public String toString() {
        return "Configuracion{" +
                "modo='" + modo + '\'' +
                ", temperatura=" + temperatura +
                ", duracion=" + duracion +
                " min}";
    }
}
