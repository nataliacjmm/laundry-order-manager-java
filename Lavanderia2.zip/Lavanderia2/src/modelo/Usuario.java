package modelo;

public class Usuario {
    private String nombre;
    private String email;
    private String telefono;
    private int id;
    
    public Usuario(String nombre, String email, String telefono, int id) {
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.id = id;
    }
    public Usuario() {
    }
    
    public String getNombre() {
        return nombre;
    }
    
    
    public String getEmail() {
        return email;
    }
    
    public String getTelefono() {
        return telefono;
    }

    public int getId() {
        return id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
    
    @Override
    public String toString() {
        return "Usuario{" + "nombre='" + nombre + '\'' + ", email='" + email + '\'' + ", telefono='" + telefono + '\'' + '}';
    }
}
