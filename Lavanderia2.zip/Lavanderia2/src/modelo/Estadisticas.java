package modelo;

import java.util.List;

public class Estadisticas {
    private List<Pedido> pedidos;
    
    public Estadisticas(List<Pedido> pedidos) {
        this.pedidos = pedidos;
    }
    
    public int totalPedidos() {
        return pedidos.size();
    }
    
}
