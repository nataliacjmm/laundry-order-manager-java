package modelo;

public class Prenda {
    private String tipo;
    private String material;
    private String color;
    
    public Prenda(String tipo, String material, String color) {
        this.tipo = tipo;
        this.material = material;
        this.color = color;
    }
    
    public String getTipo() {
        return tipo;
    }
    
    public String getMaterial() {
        return material;
    }
    
    public String getColor() {
        return color;
    }
}
