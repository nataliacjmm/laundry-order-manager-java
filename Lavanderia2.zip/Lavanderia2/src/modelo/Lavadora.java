package modelo;

public class Lavadora {
    private int id;
    private String modelo;
    private boolean enUso;
    private Pedido pedidoActual;
    
    public Lavadora(int id, String modelo) {
        this.id = id;
        this.modelo = modelo;
        this.enUso = false;
    }
    
    public int getId() {
        return id;
    }
    
    public String getModelo() {
        return modelo;
    }
    
    public boolean isEnUso() {
        return enUso;
    }
    
    public Pedido getPedidoActual() {
        return pedidoActual;
    }
    
    public void iniciarLavado(Pedido pedido) {
        if (!enUso) {
            enUso = true;
            pedidoActual = pedido;
        }
    }
    
    public void finalizarLavado() {
        enUso = false;
        pedidoActual = null;
    }
}
