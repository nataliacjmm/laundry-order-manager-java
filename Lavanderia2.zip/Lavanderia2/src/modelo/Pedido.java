package modelo;

import java.util.List;

public class Pedido {
    private int id;
    private Usuario usuario;
    private List<Prenda> prendas;
    private String programa;      // Ejemplo: "Frío", "Mixto", "Delicado", "Algodón"
    private String descripcion;   // Detalle del pedido, por ejemplo: "5kg de ropa"
    private String direccion;
    private String comentarios;
    private double costo;
    private EstadoPedido estado;  // Ahora se usa el enum

    // Constructor completo
    public Pedido(int id, Usuario usuario, List<Prenda> prendas, String programa, String descripcion, String direccion, String comentarios, double costo) {
        this.id = id;
        this.usuario = usuario;
        this.prendas = prendas;
        this.programa = programa;
        this.descripcion = descripcion;
        this.direccion = direccion;
        this.comentarios = comentarios;
        this.costo = costo;
        this.estado = EstadoPedido.PENDIENTE; // Estado inicial por defecto
    }

    // Getters y Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public List<Prenda> getPrendas() {
        return prendas;
    }

    public void setPrendas(List<Prenda> prendas) {
        this.prendas = prendas;
    }

    public String getPrograma() {
        return programa;
    }

    public void setPrograma(String programa) {
        this.programa = programa;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    public double getCosto() {
        return costo;
    }

    public void setCosto(double costo) {
        this.costo = costo;
    }

    public EstadoPedido getEstado() {
        return estado;
    }

    public void setEstado(EstadoPedido estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Pedido{" +
                "id=" + id +
                ", usuario=" + usuario.getNombre() +
                ", programa='" + programa + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", direccion='" + direccion + '\'' +
                ", comentarios='" + comentarios + '\'' +
                ", costo=" + costo +
                ", estado=" + estado +
                '}';
    }
}
