package vista;

import controlador.ControladorPedidos;
import controlador.ControladorLavadora;
import javax.swing.*;
import java.awt.*;

public class VistaAdminPedidos extends JPanel {
    private ControladorPedidos controladorPedidos;
    private ControladorLavadora controladorLavadora;
    private JTabbedPane pestañas;

    public VistaAdminPedidos(ControladorPedidos controladorPedidos, ControladorLavadora controladorLavadora, JTabbedPane pestañas) {
        this.controladorPedidos = controladorPedidos;
        this.controladorLavadora = controladorLavadora;
        this.pestañas = pestañas;
        initComponents();
    }

    private void initComponents() {
        setLayout(new GridLayout(3, 1, 20, 20));

        JButton btnVerPedidos = new JButton("Ver Pedidos");
        JButton btnCambiarEstado = new JButton("Cambiar Estado Pedido");
        JButton btnConfigurarLavadora = new JButton("Configurar Lavadora");

        btnVerPedidos.setFont(new Font("Arial", Font.BOLD, 30));
        btnCambiarEstado.setFont(new Font("Arial", Font.BOLD, 30));
        btnConfigurarLavadora.setFont(new Font("Arial", Font.BOLD, 30));

        btnVerPedidos.addActionListener(e -> pestañas.setComponentAt(1, new VistaHistorialPedidos(controladorPedidos, controladorLavadora, pestañas)));
        btnCambiarEstado.addActionListener(e -> pestañas.setComponentAt(1, new VistaEstadoPedido(controladorPedidos, controladorLavadora, pestañas)));
        btnConfigurarLavadora.addActionListener(e -> pestañas.setComponentAt(1, new VistaConfiguracionLavadora(controladorLavadora, controladorPedidos, pestañas)));

        add(btnVerPedidos);
        add(btnCambiarEstado);
        add(btnConfigurarLavadora);
    }
}
