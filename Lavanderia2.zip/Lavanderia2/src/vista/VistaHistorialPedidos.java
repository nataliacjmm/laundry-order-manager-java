package vista;

import controlador.ControladorLavadora;
import controlador.ControladorPedidos;
import modelo.Pedido;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class VistaHistorialPedidos extends JPanel {
    private ControladorPedidos controladorPedidos;
    private ControladorLavadora controladorLavadora;
    private JTable tablaPedidos;
    private DefaultTableModel modeloTabla;
    private JTabbedPane pestañas;

    public VistaHistorialPedidos(ControladorPedidos controladorPedidos, ControladorLavadora controladorLavadora, JTabbedPane pestañas) {
        this.controladorPedidos = controladorPedidos;
        this.controladorLavadora = controladorLavadora;
        this.pestañas = pestañas;
        initComponents();
        actualizarTabla();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        String[] columnas = {"ID", "Usuario", "Programa", "Kg", "Estado"};
        modeloTabla = new DefaultTableModel(columnas, 0);
        tablaPedidos = new JTable(modeloTabla);
        tablaPedidos.setFont(new Font("Arial", Font.PLAIN, 30));
        tablaPedidos.setRowHeight(25);

        JScrollPane scrollPane = new JScrollPane(tablaPedidos);
        add(scrollPane, BorderLayout.CENTER);

        JPanel panelBoton = new JPanel();
        JButton btnVolver = new JButton("← Volver");
        btnVolver.setFont(new Font("Arial", Font.BOLD, 30));
        btnVolver.addActionListener(e -> pestañas.setComponentAt(0, new VistaMenuCliente(controladorPedidos, controladorLavadora, pestañas)));
        btnVolver.addActionListener(e -> pestañas.setComponentAt(1, new VistaAdminPedidos(controladorPedidos, controladorLavadora, pestañas)));
        panelBoton.add(btnVolver);
        add(panelBoton, BorderLayout.SOUTH);
    }

    public void actualizarTabla() {
        modeloTabla.setRowCount(0);
        for (Pedido pedido : controladorPedidos.getPedidos()) {
            modeloTabla.addRow(new Object[]{
                pedido.getId(),
                pedido.getUsuario().getNombre(),
                pedido.getPrograma(),
                pedido.getDescripcion(),
                pedido.getEstado()
            });
        }
    }
}
