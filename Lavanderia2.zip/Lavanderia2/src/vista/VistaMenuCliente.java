package vista;

import controlador.ControladorLavadora;
import controlador.ControladorPedidos;
import javax.swing.*;
import java.awt.*;

public class VistaMenuCliente extends JPanel {
    private ControladorPedidos controladorPedidos;
    private ControladorLavadora controladorLavadora;
    private JTabbedPane pestañas;

    public VistaMenuCliente(ControladorPedidos controladorPedidos, ControladorLavadora controladorLavadora, JTabbedPane pestañas) {
        this.controladorPedidos = controladorPedidos;
        this.controladorLavadora = controladorLavadora;
        this.pestañas = pestañas;
        initComponents();
    }

    private void initComponents() {
        setLayout(new GridLayout(3, 1, 20, 20));

        JButton btnCrearPedido = new JButton("Crear Pedido");
        JButton btnVerHistorial = new JButton("Historial de Pedidos");
        JButton btnEstadoPedido = new JButton("Estado de Pedido");

        btnCrearPedido.setFont(new Font("Arial", Font.BOLD, 30));
        btnVerHistorial.setFont(new Font("Arial", Font.BOLD, 30));
        btnEstadoPedido.setFont(new Font("Arial", Font.BOLD, 30));

        // Acciones de los botones
        btnCrearPedido.addActionListener(e -> pestañas.setComponentAt(0, new VistaCreacionPedido(controladorPedidos, controladorLavadora, pestañas)));
        btnVerHistorial.addActionListener(e -> pestañas.setComponentAt(0, new VistaHistorialPedidos(controladorPedidos, controladorLavadora, pestañas)));
        btnEstadoPedido.addActionListener(e -> pestañas.setComponentAt(0, new VistaEstadoPedido(controladorPedidos, controladorLavadora, pestañas)));

        add(btnCrearPedido);
        add(btnVerHistorial);
        add(btnEstadoPedido);
    }
}
