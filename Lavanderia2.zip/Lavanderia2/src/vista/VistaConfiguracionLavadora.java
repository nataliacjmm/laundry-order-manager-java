package vista;

import controlador.ControladorLavadora;
import controlador.ControladorPedidos;
import modelo.Configuracion;
import modelo.EstadoPedido;
import modelo.Lavadora;
import modelo.Pedido;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

public class VistaConfiguracionLavadora extends JPanel {
    private ControladorLavadora controladorLavadora;
    private ControladorPedidos controladorPedidos;
    private JTabbedPane pestañas;

    public VistaConfiguracionLavadora(ControladorLavadora controladorLavadora, ControladorPedidos controladorPedidos, JTabbedPane pestañas) {
        this.controladorLavadora = controladorLavadora;
        this.controladorPedidos = controladorPedidos;
        this.pestañas = pestañas;
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));

        JLabel lblModo = new JLabel("Modo:");
        JComboBox<String> comboModo = new JComboBox<>(new String[]{"Frío", "Mixto", "Delicado", "Algodón"});

        JLabel lblTemperatura = new JLabel("Temperatura:");
        JTextField txtTemperatura = new JTextField();

        JLabel lblDuracion = new JLabel("Duración (min):");
        JTextField txtDuracion = new JTextField();

        JLabel lblLavadora = new JLabel("Lavadora:");
        JComboBox<Lavadora> comboLavadora = new JComboBox<>();
        List<Lavadora> lavadoras = controladorLavadora.getLavadoras();
        for (Lavadora lavadora : lavadoras) {
            comboLavadora.addItem(lavadora);
        }

        JLabel lblPedido = new JLabel("Pedido Pendiente:");
        JComboBox<Pedido> comboPedido = new JComboBox<>();
        for (Pedido pedido : controladorPedidos.getPedidos()) {
            if (pedido.getEstado() == EstadoPedido.PENDIENTE) {
                comboPedido.addItem(pedido);
            }
        }

        JPanel panelBoton = new JPanel();
        JButton btnIniciar = new JButton("Iniciar Lavado");
        JButton btnVolver = new JButton("← Volver");
        btnVolver.setFont(new Font("Arial", Font.BOLD, 30));
        btnVolver.addActionListener(e -> pestañas.setComponentAt(1, new VistaAdminPedidos(controladorPedidos, controladorLavadora, pestañas)));
        panelBoton.add(btnVolver);
        add(panelBoton, BorderLayout.SOUTH);

        panel.add(lblModo);
        panel.add(comboModo);
        panel.add(lblTemperatura);
        panel.add(txtTemperatura);
        panel.add(lblDuracion);
        panel.add(txtDuracion);
        panel.add(lblLavadora);
        panel.add(comboLavadora);
        panel.add(lblPedido);
        panel.add(comboPedido);
        panel.add(btnIniciar);
        panel.add(btnVolver);

        add(panel, BorderLayout.CENTER);

        btnIniciar.addActionListener(e -> {
            String modo = comboModo.getSelectedItem().toString();
            int temperatura, duracion;

            try {
                temperatura = Integer.parseInt(txtTemperatura.getText());
                duracion = Integer.parseInt(txtDuracion.getText());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Ingresa valores numéricos válidos.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Lavadora lavadoraSeleccionada = (Lavadora) comboLavadora.getSelectedItem();
            Pedido pedidoSeleccionado = (Pedido) comboPedido.getSelectedItem();

            if (lavadoraSeleccionada == null || pedidoSeleccionado == null) {
                JOptionPane.showMessageDialog(this, "Selecciona una lavadora y un pedido.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (lavadoraSeleccionada.isEnUso()) {
                JOptionPane.showMessageDialog(this, "La lavadora está en uso.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            lavadoraSeleccionada.iniciarLavado(pedidoSeleccionado);
            controladorPedidos.actualizarEstadoPedido(pedidoSeleccionado.getId(), EstadoPedido.EN_PROCESO);
            JOptionPane.showMessageDialog(this, "Lavado iniciado.");

            Timer timer = new Timer(duracion * 60000, evt -> {
                lavadoraSeleccionada.finalizarLavado();
                controladorPedidos.actualizarEstadoPedido(pedidoSeleccionado.getId(), EstadoPedido.COMPLETADO);
                JOptionPane.showMessageDialog(this, "Lavado completado.");
            });

            timer.setRepeats(false);
            timer.start();
        });

    }
}
