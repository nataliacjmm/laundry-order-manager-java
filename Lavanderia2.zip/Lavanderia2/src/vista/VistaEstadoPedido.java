package vista;

import controlador.ControladorLavadora;
import controlador.ControladorPedidos;
import modelo.Pedido;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class VistaEstadoPedido extends JPanel {
    private ControladorPedidos controladorPedidos;
    private ControladorLavadora controladorLavadora;
    private JTabbedPane pestañas;
    private JTable tablaEstado;
    private DefaultTableModel modeloTabla;
    private JTextField tfIdPedido;

    public VistaEstadoPedido(ControladorPedidos controladorPedidos, ControladorLavadora controladorLavadora, JTabbedPane pestañas) {
        this.controladorPedidos = controladorPedidos;
        this.controladorLavadora = controladorLavadora;
        this.pestañas = pestañas;
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel panelBusqueda = new JPanel(new FlowLayout());
        panelBusqueda.add(new JLabel("ID del Pedido:"));
        tfIdPedido = new JTextField(5);
        panelBusqueda.add(tfIdPedido);

        JButton btnBuscar = new JButton("Buscar");
        btnBuscar.addActionListener(e -> buscarPedido());

        panelBusqueda.add(btnBuscar);
        add(panelBusqueda, BorderLayout.NORTH);

        String[] columnas = {"ID", "Usuario", "Programa", "Kg", "Estado"};
        modeloTabla = new DefaultTableModel(columnas, 0);
        tablaEstado = new JTable(modeloTabla);
        tablaEstado.setFont(new Font("Arial", Font.PLAIN, 30));
        tablaEstado.setRowHeight(25);

        JScrollPane scrollPane = new JScrollPane(tablaEstado);
        add(scrollPane, BorderLayout.CENTER);

        JPanel panelBoton = new JPanel();
        JButton btnVolver = new JButton("← Volver");
        btnVolver.addActionListener(e -> pestañas.setComponentAt(0, new VistaMenuCliente(controladorPedidos, controladorLavadora, pestañas)));
        btnVolver.addActionListener(e -> pestañas.setComponentAt(1, new VistaAdminPedidos(controladorPedidos, controladorLavadora, pestañas)));

        panelBoton.add(btnVolver);
        add(panelBoton, BorderLayout.SOUTH);
    }

    private void buscarPedido() {
        try {
            int id = Integer.parseInt(tfIdPedido.getText().trim());
            Pedido pedido = controladorPedidos.getPedidos().stream().filter(p -> p.getId() == id).findFirst().orElse(null);

            if (pedido != null) {
                modeloTabla.setRowCount(0);
                modeloTabla.addRow(new Object[]{
                    pedido.getId(),
                    pedido.getUsuario().getNombre(),
                    pedido.getPrograma(),
                    pedido.getDescripcion(),
                    pedido.getEstado()
                });
            } else {
                JOptionPane.showMessageDialog(this, "Pedido no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Ingrese un ID válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
