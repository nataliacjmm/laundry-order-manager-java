package vista;

import controlador.ControladorLavadora;
import controlador.ControladorPedidos;
import modelo.Pedido;
import modelo.Prenda;
import modelo.Usuario;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class VistaCreacionPedido extends JPanel {
    private ControladorPedidos controladorPedidos;
    private ControladorLavadora controladorLavadora;
    private JTabbedPane pestañas;

    private JTextField tfNombre;
    private JComboBox<String> cbPrograma;
    private JSlider sliderKg;
    private JComboBox<String> cbTipoPrenda;
    private JTextField tfDireccion;
    private JTextField tfComentarios;
    private DefaultListModel<String> listaPrendasModel;
    private JList<String> listaPrendas;

    public VistaCreacionPedido(ControladorPedidos controladorPedidos, ControladorLavadora controladorLavadora, JTabbedPane pestañas) {
        this.controladorPedidos = controladorPedidos;
        this.controladorLavadora = controladorLavadora;
        this.pestañas = pestañas;
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50)); 

        JPanel formPanel = new JPanel(new GridLayout(0, 2, 10, 10));

        formPanel.add(new JLabel("Nombre:"));
        tfNombre = new JTextField();
        formPanel.add(tfNombre);

        formPanel.add(new JLabel("Programa de lavado:"));
        cbPrograma = new JComboBox<>(new String[]{"Frío", "Mixto", "Delicado", "Algodón"});
        formPanel.add(cbPrograma);

        formPanel.add(new JLabel("Kg de ropa:"));
        sliderKg = new JSlider(1, 10, 5);
        sliderKg.setMajorTickSpacing(1);
        sliderKg.setPaintTicks(true);
        sliderKg.setPaintLabels(true);
        formPanel.add(sliderKg);

        formPanel.add(new JLabel("Tipo de prenda:"));
        cbTipoPrenda = new JComboBox<>(new String[]{"Camisa", "Pantalón", "Chaqueta", "Falda", "Ropa interior", "Otro"});
        formPanel.add(cbTipoPrenda);

        JButton btnAgregarPrenda = new JButton("Añadir prenda");
        btnAgregarPrenda.addActionListener(e -> agregarPrenda());
        formPanel.add(btnAgregarPrenda);

        listaPrendasModel = new DefaultListModel<>();
        listaPrendas = new JList<>(listaPrendasModel);
        JScrollPane scrollPane = new JScrollPane(listaPrendas);
        formPanel.add(scrollPane);

        formPanel.add(new JLabel("Dirección de envío:"));
        tfDireccion = new JTextField();
        formPanel.add(tfDireccion);

        formPanel.add(new JLabel("Comentarios:"));
        tfComentarios = new JTextField();
        formPanel.add(tfComentarios);

        add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton btnCrear = new JButton("Crear Pedido");
        btnCrear.addActionListener(e -> crearPedido());

        JButton btnVolver = new JButton("← Volver");
        btnVolver.addActionListener(e -> pestañas.setComponentAt(0, new VistaMenuCliente(controladorPedidos, controladorLavadora, pestañas)));

        buttonPanel.add(btnCrear);
        buttonPanel.add(btnVolver);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void agregarPrenda() {
        String tipoPrenda = (String) cbTipoPrenda.getSelectedItem();
        if (tipoPrenda != null) {
            listaPrendasModel.addElement(tipoPrenda);
        }
    }

    private void crearPedido() {
        try {
            String nombre = tfNombre.getText().trim();
            String programa = (String) cbPrograma.getSelectedItem();
            int kgRopa = sliderKg.getValue();
            String direccion = tfDireccion.getText().trim();
            String comentarios = tfComentarios.getText().trim();

            if (nombre.isEmpty() || direccion.isEmpty()) {
                JOptionPane.showMessageDialog(this, "El nombre y la dirección son obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Usuario usuario = new Usuario(nombre, "email@example.com", "000000000");

            List<Prenda> prendas = new ArrayList<>();
            for (int i = 0; i < listaPrendasModel.size(); i++) {
                prendas.add(new Prenda(listaPrendasModel.get(i), "Algodón", "Blanco"));
            }

            int idPedido = controladorPedidos.getPedidos().size() + 1;
            Pedido pedido = new Pedido(idPedido, usuario, prendas, programa, kgRopa + "kg", direccion, comentarios, 10.0);
            controladorPedidos.agregarPedido(pedido);

            JOptionPane.showMessageDialog(this, "Pedido creado con éxito.");
            limpiarCampos();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al crear el pedido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarCampos() {
        tfNombre.setText("");
        cbPrograma.setSelectedIndex(0);
        sliderKg.setValue(5);
        listaPrendasModel.clear();
        tfDireccion.setText("");
        tfComentarios.setText("");
    }
}
